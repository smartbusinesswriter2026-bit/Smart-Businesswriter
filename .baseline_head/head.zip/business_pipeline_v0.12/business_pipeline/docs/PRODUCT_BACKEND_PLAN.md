# Product backend plan (after the freeze)

**Status: PROVISIONAL plan, owner instruction "finish the backend product before finally doing the UI".** The core is frozen (B-079); the product backend is the design owner's lane and is additive only (B-080). This file fixes the order, the owner of each slice, the gates, and the boundary rules that keep the frozen contract intact while both owners work in the same repo.

Read with [`BACKEND_CONTRACT.md`](BACKEND_CONTRACT.md) (frozen core) and [`DECISIONS.md`](DECISIONS.md) B-079/B-080/B-081.

## Phase 0 — owner decisions that shape the backend

These do not block slice 1 (which is built to the conservative default in the third column), but they must be answered before any hosted/multi-user work or any promise about data retention.

| # | Question | Recommended default (slice-1-safe) | What changes if the owner chooses differently |
|---|---|---|---|
| D1 | **Deployment model**: local single-user, or hosted multi-user? | **Local single-user v1**: one person, one machine, files on disk, no accounts. | Hosted brings accounts/auth, tenancy isolation, backups, rate limits and a security review; the case store's storage layer changes but the frozen computation does not. |
| D2 | **Case retention/privacy**: how long are cases kept, who may delete them, is any case content sent anywhere? | **Keep until the owner deletes; no outbound transfer; model assistance stays opt-in and off by default (already true).** | A retention policy adds expiry/export-before-delete rules; privacy law review is needed before hosting. |
| D3 | **AI-use disclosure audience**: for an assessor/reviewer, an institution, or an internal file? | **A reviewer/assessor-facing disclosure** generated from recorded metadata (method id/version, spec hash, tier, run id, environment hash, declared inputs provenance, model-assistance calls if any, verification checks, timestamps). | Different audiences change what is shown (e.g. institution paperwork) but not what is recorded, because the record already exists. |
| D4 | **Reviewer sign-off semantics**: what does a signature assert? | **"I reviewed the named bundle and its disclosed limitations"; it does not assert the inputs are true or the analysis is correct.** | A stronger claim needs a named reviewer (B-005) and a process; the record schema stays the same. |

**Owner answers (2026-10-21, B-083):** **D1 accepted** — local single-user v1 first ("more improvement later, but I need to see this working first"). **D2 accepted** — cases kept until the owner deletes them, no outbound transfer, model assistance stays opt-in/off by default. **D3 deferred** — the AI-use disclosure export is removed from slice 1 and returns as its own later, separately decided slice; slice 1 does not build it. **D4 open** — the owner asked for an explanation; sign-off is Phase 2 and the record schema does not depend on the wording.

### D1 amended 2026-11-03 (B-209) — the shared login reopens the deployment model

The Business Bundle is **one order, one charge and one login** (B-208). "One login" means the
same email and password signs in on Smart Business Writer and on Write Smarter, so Smart Business
Writer now has accounts, a sign-in, a per-account wallet and a reachable HTTPS origin. D1's
"local single-user v1: one person, one machine, files on disk, no accounts" no longer describes the
whole product, and the plan says so rather than leaving the two in conflict.

**What changes:**

| | Before (D1, 2026-10-21) | After (B-209) |
|---|---|---|
| Deployment | Local single-user v1 | **Hosted multi-user for the bundle** — accounts, tenancy isolation and per-user quota are in scope |
| Accounts | None | **Per-account wallet, cases and plan**; the existing machine-local records become the first account and migrate without loss |
| Case store | Local, opaque, one directory | Unchanged — still local and opaque for now; tenancy isolation is the identity slice's work, not the store's |
| Authentication | None | A sign-in in the workbench, and the same credentials on both products |
| Outbound calls | None | One outbound call, to the other product, to grant the bundle — and only for the bundle |

**What does not change:** the frozen core, the case bundle as an opaque document, the export gate,
and every rule about invented numbers. The identity work is deliberately **after** the payment
work: the owner asked for the payment to be settled and proved against live PayPal first, because
the login only decides *which account* the subscription attaches to, not whether the charge
happens. The shared secret that lets the two products talk is server-side only and never appears
in a page.

## Phase 1 — slice 1, delegated to the design owner (MiniMax)

Delivered as one product increment against the frozen core, with no unfreeze.

**1a. Case workspace store (local, durable).**
- New package `src/bp/product/` (new files only; it imports the frozen core, never modifies it).
- Stores a **case bundle** as one JSON document per case under a data directory (`BP_CASES_DIR`, default `cases/`): the session JSON (`session.to_dict()`), the delivery `report` + `appendix`, the `reperform` bundle, and case metadata (`id`, `title`, `created_at`, `method`, `tier`, `spec_hash`, `outputs_hash`). The bundle is an **opaque document**: the product layer does not reinterpret, recompute or "fix" any number in it.
- Atomic writes (write-temp-then-rename), `id` generated by the product layer (hex), path-traversal refused, a corrupt bundle refuses to load with a clear message, delete removes the file.
- Additive routes: `GET /api/cases`, `POST /api/cases`, `GET /api/cases/{id}`, `DELETE /api/cases/{id}`. No route computes; loading a case shows the stored report verbatim.

**1b. (Deferred, D3) AI-use disclosure export.**
Owner deferred it on 2026-10-21 ("lets add the disclosure later. this is not done"). It is **not part of slice 1**; it returns later as its own slice and needs a decision on the audience and the wording before anything is built. Slice 1 must not include the word "disclosure" as a feature, and the product layer must not claim one.

**1c. Report export (v1: stdlib HTML; Office formats later).**
- `export_html(bundle, path)`: one self-contained HTML file (no third-party dependency) containing the delivered report text **verbatim**, the artifacts table, and the stored limitations/honesty notes. Numbers appear exactly as stored — no re-formatting, re-rounding, summarising or restyling of claim wording.
- DOCX/XLSX are a **later** slice: they need a product-layer dependency (python-docx/openpyxl), which must be declared and reviewed before it is added; the stdlib core keeps importing nothing new.

**Boundary rules for this slice (binding):**
- May create: `src/bp/product/**` (new files), `tests/test_product_*.py` (new flat test files), `web/**` presentation, product docs.
- May edit for its own increment, and only these: the **count/version digits** in `docs/HOME.md`, `docs/HANDOFF.md`, `docs/CONTRIBUTORS.md`; one `CHANGELOG.md` entry; one `WORKLOG.md` entry tagged `[product]`; its own rows in `BACKEND_CONTRACT.md` §6.
- May **not** edit: any frozen core module, any existing test or fixture (`tests/fixtures/frozen_contract.json` included), `docs/DECISIONS.md`, `docs/BACKEND_CONTRACT.md` §1-§5, `docs/KNOWN_LIMITATIONS.md`, `docs/PRODUCT_GAP_MAP.md`, `docs/RESEARCH_EVIDENCE_WORKFLOW.md`, or any caveat/honesty/claim wording.
- The suite must be green including `tests/test_frozen_contract.py` and `tests/test_docs_sync.py`. The computation owner reviews the numeric doc edits at merge.

## Phase 2 — slice 2, delegated to the design owner (now implemented by the computation owner)

*Owner instruction 2026-10-21: "do it yourself the job you are delegating" — slice 2 is implemented by the computation owner, in the product layer, so no review round-trip is needed.*

**2a — SHIPPED (B-086, build 0.61):** immutable case versions, the Option-A multi-period comparison (same-method rule, rows aligned by metric, stored values verbatim, missing metrics reported as not computed, per-version hash disclosure, stdlib HTML rendering) and the append-only reviewer sign-off with the owner-approved Option-A wording and tamper evidence.

- ~~Reviewer sign-off record~~ — **done in 2a** (append-only records with the owner-approved Option-A wording and the signed per-version hashes).
- ~~Multi-period comparatives and case versioning (Option A)~~ — **done in 2a** (immutable versions; comparison with declared comparability rules and stored values only).
- ~~Model pinning / drift gate surface~~ — **covered in 2b**: `/api/health` reports whether model assistance is on and `/api/assist/config` reports the provider/model ids and call counts; no new model capability.
- ~~Ops and observability~~ — **done in 2b** for the local scope: content-free request log, health endpoint, backup/restore. A hosted deployment would add rate limits and external log shipping under D1's later "improve" step.
- ~~Offline packaging~~ — **done in 2b**: `scripts/serve.py` is the single local run path with a `--check` dry-run; a packaged installer (or pyproject/one-file build) is deferred until the UI phase is settled.
- **2b — remaining:** AI-use disclosure export (deferred by D3; needs its own decision on audience/wording).

## Phase 2c — deliverable graphics and spreadsheets (B-087; before the UI)

**SHIPPED (B-089, build 0.63):** `src/bp/product/charts.py` (declarative `bp-chart/1` spec → deterministic SVG for bar/line/stacked bar/waterfall/pie/sparkline/table, stored values only, digit-free labels, missing or non-numeric artifacts refused), `src/bp/product/spreadsheets.py` (CSV + SpreadsheetML 2003 workbook of stored strings), `src/bp/product/diagrams.py` (structure-only SVG templates: process, 2x2 matrix, pyramid, funnel, tree), `export_html(charts=…, diagrams=…)`, and the render/export routes. No model call in the rendering path.

Design record (as planned):

- **Declarative graphic spec** (product layer): a small JSON document naming the chart type and the stored series to draw (e.g. `{"kind": "bar", "title": "...", "series": [{"label": "NPV", "artifact": "npv"}]}`). The renderer looks every value up in a stored bundle; a spec that names an artifact the bundle does not record is refused, and a chart cannot introduce a number, axis label or annotation that is not a stored value.
- **Charts** rendered as deterministic **SVG** (stdlib string building): bar, line, stacked bar, waterfall, pie/donut, sparkline, and a table view; every bar/point labelled with the stored string. Charts embed in the HTML export and in the comparison view.
- **Spreadsheet export** as **CSV** (stdlib) and **SpreadsheetML 2003 XML** (stdlib; opens in Excel/LibreOffice) with one sheet per artifact table and the report text kept verbatim. A native `.xlsx` writer (OOXML zip) is a later option if the SpreadsheetML path proves limiting; it is still stdlib.
- **Business graphics**: diagram templates as declarative SVG from owner-supplied labels (process, matrix/2×2, pyramid, funnel, org-style tree), T4 structure-only — they organise the owner's words and compute nothing; a model may *suggest* labels only under the proposals-only boundary and its output is audited before use.
- **Model tiering (B-087)**: while the pipeline is being proven, the optional assist lane runs on free/cheap OpenAI-compatible endpoints (local Ollama or a free tier); later it upgrades to a paid tier (DeepSeek Pro-class for numeric narrative, Claude Sonnet-class for prose/design critique, Gemini Flash/Pro-class for multimodal suggestions). The chart/table renderer does not call a model at all, so a weaker free model cannot make a graphic wrong.
- **Acceptance for 2c**: deterministic bytes for the same bundle+spec; every rendered number equals a stored value (boundary test); a spec naming a missing artifact or a non-stored metric blocks with a reason; CSV/SpreadsheetML round-trip the stored strings; SVG is well-formed XML with no external resources; no model call in the rendering path.

## Phase 3 — computation owner, needs an unfreeze (owner approval, B-079)

Ordered by product value:

1. **PDF/scan/OCR + SPSS ingestion** — extraction pipeline plus a human-confirmation step for unverified text; unfreeze because the ingest contract changes.
2. **Core-lane exports** if the Office export must live in `report.py` rather than the product layer (prefer product layer).

(The former item "multi-period comparatives / case versioning" was resolved by the owner on 2026-10-21 as **Option A** and moved to the delegated Phase 2, because it needs no unfreeze.)

Each starts as a request in this file; nothing here is approved yet.

## Phase 4 — owner-gated tracks (cannot start without decisions)

- **REW stages R0-R8** — needs R1-R10 ratification (see [`proposals/DECISION_BRIEFS.md`](proposals/DECISION_BRIEFS.md) Brief 5).
- **Standards / filings / tax retrieval** — needs source and licensing decisions.
- **Tax computation (B-052), ledger engine (B-032), template breadth (B-028)** - existing open decisions; reviewer naming is not planned (B-112).
- **Real-case held-out evaluation** — needs a governance decision on real data; the scaffold exists and is synthetic-only.

## Phase 5 — the UI

Only after Phase 1-2 are accepted: the workbench design pass runs against the frozen contract + the product layer, still in the design owner's lane, still unable to change numbers, caveats or claim wording. The product surface rows in [`BACKEND_CONTRACT.md`](BACKEND_CONTRACT.md) §6 are the interface it builds against.

**Owner-supplied UI reference:** `A1.jpg` at the workspace root (added 2026-10-21 as a website reference) is outside the repository and is not committed; the design owner may use it when this phase starts. The logo image(s) at the workspace root are likewise the owner's and out of scope for the computation lane.

## Definition of done for this plan

- [ ] D1-D4 answered — **done 2026-10-21** (B-083, B-084); D3 disclosure remains deferred by choice.
- [ ] Slice 1 (case store + route dispatch + stdlib HTML export) merged with product tests; frozen contract and docs guards still green.
- [ ] Slice 2 (sign-off record with the Option-A wording, multi-period comparatives + case versioning per Option A, ops/observability, packaging) merged.
- [ ] Every frozen-contract change requested in Phase 3 is either approved with a B-decision or explicitly dropped.
- [ ] The case store passes an export/restore round-trip and a delete test, and no product route computes a number.
